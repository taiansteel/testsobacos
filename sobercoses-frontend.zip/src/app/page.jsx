"use client";

import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import axios from "axios";

export default function FurniturePage() {
  const [items, setItems] = useState([]);
  const [selectedMaterial, setSelectedMaterial] = useState(null);
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(1000000);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 4;

  useEffect(() => {
    axios.get("https://your-backend-api.com/api/furniture")
      .then((response) => setItems(response.data))
      .catch((error) => console.error("Error fetching items:", error));
  }, []);

  const parsePrice = (price) => parseInt(price.toString().replace(/[$,]/g, ""), 10);

  const filteredItems = items.filter((item) => {
    const itemPrice = parsePrice(item.price);
    const matchesMaterial = selectedMaterial ? item.material === selectedMaterial : true;
    const matchesPrice = itemPrice >= minPrice && itemPrice <= maxPrice;
    return matchesMaterial && matchesPrice;
  });

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
  const displayedItems = filteredItems.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const uniqueMaterials = Array.from(new Set(items.map((item) => item.material)));

  return (
    <div className="p-6 bg-white min-h-screen">
      <div className="text-center mb-8">
        <h2 className="text-xl font-semibold mb-2">Filter by Material</h2>
        <div className="flex flex-wrap justify-center gap-3">
          {uniqueMaterials.map((material) => (
            <Button
              key={material}
              variant={selectedMaterial === material ? "default" : "outline"}
              onClick={() => setSelectedMaterial(selectedMaterial === material ? null : material)}
            >
              {material}
            </Button>
          ))}
        </div>
      </div>

      <div className="text-center mb-8">
        <h2 className="text-xl font-semibold mb-2">Filter by Price</h2>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <input
            type="number"
            value={minPrice}
            onChange={(e) => setMinPrice(Number(e.target.value))}
            placeholder="Min Price"
            className="border border-gray-300 rounded p-2 w-40"
          />
          <input
            type="number"
            value={maxPrice}
            onChange={(e) => setMaxPrice(Number(e.target.value))}
            placeholder="Max Price"
            className="border border-gray-300 rounded p-2 w-40"
          />
        </div>
      </div>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {displayedItems.map((item) => (
          <Card key={item.id} className="shadow-xl rounded-2xl overflow-hidden">
            <img src={item.image} alt={item.name} className="w-full h-48 object-cover" />
            <CardContent className="p-4">
              <h2 className="text-xl font-semibold mb-1">{item.name}</h2>
              <p className="text-sm text-gray-500 mb-1">{item.material}</p>
              <p className="text-lg text-gray-600">{item.price}</p>
              <Button className="mt-4 w-full">Inquire Now</Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <div className="flex justify-center mt-8 space-x-4">
        <Button onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))} disabled={currentPage === 1}>
          Previous
        </Button>
        <span className="self-center">Page {currentPage} of {totalPages}</span>
        <Button onClick={() => setCurrentPage((p) => Math.min(p + 1, totalPages))} disabled={currentPage === totalPages}>
          Next
        </Button>
      </div>
    </div>
  );
}